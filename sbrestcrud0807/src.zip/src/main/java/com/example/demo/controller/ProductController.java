package com.example.demo.controller;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;
import com.example.demo.model.ProductDTO;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    
    private final static Map<String, Product> productStore = new ConcurrentHashMap<>();
    static {
    	Product p1=new Product("Apple","USA Fruit",new BigDecimal(30.50),100);
    	productStore.put(p1.getId(),p1); 
    	p1=new Product("Banana","Taiwan Fruit",new BigDecimal(10.0),500);
    	productStore.put(p1.getId(),p1); 
    	p1=new Product("Cherry","Canada Fruit",new BigDecimal(300.0),1000);
    	productStore.put(p1.getId(),p1); 
    }    
    // GET /api/products - 取得所有產品
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = new ArrayList<>(productStore.values());
        return ResponseEntity.ok(products);
    }
 // POST /api/products - 建立新產品
    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody ProductDTO product) {
        if (product.getName() == null || product.getName().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        
        Product newProduct = new Product(
            product.getName(),
            product.getDescription(),
            product.getPrice(),
            product.getStock()
        );
        
        productStore.put(newProduct.getId(), newProduct);
        return ResponseEntity.status(HttpStatus.CREATED).body(newProduct);
    }
    
 // PUT /api/products/{id} - 更新產品
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable String id, 
    		                                   @RequestBody ProductDTO product) {
        if (!productStore.containsKey(id)) {
            return ResponseEntity.notFound().build();
        }
        
        Product existingProduct = productStore.get(id);
        existingProduct.setName(product.getName());
        existingProduct.setDescription(product.getDescription());
        existingProduct.setPrice(product.getPrice());
        existingProduct.setStock(product.getStock());
        existingProduct.updateTimestamp();
        
        return ResponseEntity.ok(existingProduct);
    }
}
